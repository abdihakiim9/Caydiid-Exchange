CAYDIID EXCHANGE APP
1. Fur index.html browser-ka si aad u tijaabiso.
2. Si uu u noqdo PWA/mobile app, ku publish garee HTTPS hosting sida Netlify/Vercel/GitHub Pages, kadib browser-ka ka dooro Add to Home Screen.
3. USSD codes-ka waxaa lagu geliyey sida uu user-ku bixiyey.
4. Transactions-ku waxay ku kaydsamaan browser-ka (localStorage) ee qalabkaas.
